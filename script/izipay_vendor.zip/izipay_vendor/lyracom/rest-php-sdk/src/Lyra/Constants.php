<?php
namespace Lyra;

class Constants
{
    const SDK_VERSION = '4.0.2';
}
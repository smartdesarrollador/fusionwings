<?php
namespace Lyra\Exceptions;

use Lyra\Exceptions\LyraException;

class LyraPrettyException extends LyraException
{
}
<?php
namespace Lyra\Exceptions;


class LyraException extends \Exception
{
}